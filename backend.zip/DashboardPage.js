import React, { useState, useEffect } from 'react';
import { useAuth } from '../AuthContext';
import { useTranslation } from 'react-i18next'; 

// --- Компонент: Переключатель языков и валют ---
const LanguageCurrencySwitcher = () => {
  const { t, i18n } = useTranslation();
  // Получаем ВСЕ нужные функции
  const { token, user, setUser, currency, setCurrency } = useAuth(); 

  const currentLang = i18n.resolvedLanguage;
  const currentCurrency = currency;

  // 1. Сохранение настроек в БД
  const saveSettings = async (settingsToSave) => {
    if (!token) return; 
    try {
      await fetch('http://localhost:5000/api/client/settings', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(settingsToSave)
      });
    } catch (e) {
      console.error("Не удалось сохранить настройки", e);
    }
  };

  // 2. Смена языка
  const changeLanguage = (lng) => {
    i18n.changeLanguage(lng); 
    // Обновляем 'user' в AuthContext, чтобы избежать "гонки"
    if (user) {
        setUser(prevUser => ({ ...prevUser, preferred_lang: lng }));
    }
    saveSettings({ lang: lng }); // Сохраняем в БД
  };
  
  // 3. Смена валюты
  const changeCurrency = (curr) => {
    setCurrency(curr); // Обновляем 'currency' в AuthContext
    localStorage.setItem('userCurrency', curr); // Обновляем localStorage
    // Обновляем 'user' в AuthContext, чтобы избежать "гонки"
    if (user) {
        setUser(prevUser => ({ ...prevUser, preferred_currency: curr }));
    }
    saveSettings({ currency: curr }); // Сохраняем в БД
  };

  return (
    <div className="settings-switcher">
      <select 
        value={currentCurrency} 
        onChange={(e) => changeCurrency(e.target.value)}
        className="lang-select"
      >
        <option value="uah">₴ UAH</option>
        <option value="rub">₽ RUB</option>
        <option value="usd">$ USD</option>
      </select>
      
      <select 
        value={currentLang} 
        onChange={(e) => changeLanguage(e.target.value)}
        className="lang-select"
      >
        <option value="ru">{t('languages.ru')}</option>
        <option value="ua">{t('languages.ua')}</option>
        <option value="cn">{t('languages.cn')}</option>
      </select>
    </div>
  );
};


// --- Компонент: Кнопка "Подключиться" ---
const ConnectButton = ({ url }) => {
  const { t } = useTranslation();
  const handleConnect = () => {
    if (url) {
      window.location.href = url;
    }
  };
  return (
    <button className="btn btn-connect" onClick={handleConnect}>
      {t('dashboard.connect_button')}
    </button>
  );
};

// --- Компонент: Список серверов ---
const ServerList = ({ token }) => {
  const [nodes, setNodes] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchNodes = async () => {
      try {
        const response = await fetch('http://localhost:5000/api/client/nodes', {
          headers: { 'Authorization': `Bearer ${token}` }
        });
        if (response.ok) {
          const data = await response.json();
          setNodes(data.response?.activeNodes || []);
        }
      } catch (e) {
        console.error("Не удалось загрузить серверы", e);
      } finally {
        setLoading(false);
      }
    };
    if (token) {
        fetchNodes();
    }
  }, [token]);

  if (loading) return <div className="loading-mini">Загрузка серверов...</div>;
  if (nodes.length === 0) return <div className="empty-state">Нет доступных серверов.</div>;

  const flagMap = {
    'US': '🇺🇸', 'DE': '🇩🇪', 'NL': '🇳🇱', 'FR': '🇫🇷', 'GB': '🇬🇧',
    'UA': '🇺🇦', 'PL': '🇵🇱', 'CA': '🇨🇦', 'JP': '🇯🇵', 'AU': '🇦🇺',
  };

  return (
    <div className="server-grid">
      {nodes.map((node) => (
        <div key={node.uuid} className="server-card">
          <div className="flag">{flagMap[node.countryCode.toUpperCase()] || node.countryCode.toUpperCase()}</div>
          <div className="server-name">{node.nodeName}</div>
        </div>
      ))}
    </div>
  );
};

// --- Компонент: Кнопка "Активировать" ---
const TrialButton = ({ onUpdateUser }) => {
  const { t } = useTranslation();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const { token } = useAuth(); 

  const handleClick = async () => {
    setLoading(true);
    setError(null);
    try {
      const response = await fetch('http://localhost:5000/api/client/activate-trial', {
        method: 'POST',
        headers: { 'Authorization': `Bearer ${token}` }
      });
      const data = await response.json();
      if (!response.ok) { throw new Error(data.message || 'Ошибка активации'); }
      onUpdateUser(data.response || data); 
    } catch (err) {
      setError(err.message);
      setLoading(false);
    }
  };

  return (
    <div className="trial-container">
      <h3>{t('trial.no_subscription')}</h3>
      <button className="btn btn-trial" onClick={handleClick} disabled={loading}>
        {loading ? t('trial.activating') : t('trial.cta')}
      </button>
      {error && <div className="message-error" style={{marginTop: '10px'}}>{error || t('trial.error')}</div>}
    </div>
  );
};


// --- Компонент: Тарифы (ДИНАМИЧЕСКИЙ) ---
const TariffSection = () => {
  const { t } = useTranslation();
  const { currency } = useAuth(); // ❗️ Получаем текущую валюту
  const [tariffs, setTariffs] = useState([]);
  const [loading, setLoading] = useState(true);

  // 1. Загружаем тарифы из НАШЕЙ БД
  useEffect(() => {
    const fetchTariffs = async () => {
      setLoading(true);
      try {
        const response = await fetch('http://localhost:5000/api/public/tariffs');
        if (response.ok) {
          const data = await response.json();
          setTariffs(data);
        }
      } catch (e) { console.error("Не удалось загрузить тарифы", e); } 
      finally { setLoading(false); }
    };
    fetchTariffs();
  }, []); // ❗️ Загружаем 1 раз

  // 2. Функция для выбора ПРАВИЛЬНОЙ цены
  const getPrice = (tariff) => {
    switch(currency) {
      case 'uah': return `${tariff.price_uah} ₴`;
      case 'rub': return `${tariff.price_rub} ₽`;
      case 'usd': return `$${tariff.price_usd}`;
      default: return `${tariff.price_uah} ₴`;
    }
  };

  if (loading) return <div className="loading-mini">Загрузка тарифов...</div>;

  return (
    <div className="tariff-grid">
      {tariffs.map((tariff) => (
        <div key={tariff.id} className="tariff-card">
          {/* TODO: Добавить бейджики (скидки) */}
          <h3>{t(`tariffs.${tariff.name}`, tariff.name)}</h3> {/* Переводим название */}
          <div className="price">{getPrice(tariff)}</div>
          <div className="period">{t('tariffs.days', { count: tariff.duration_days })}</div>
          <button className="btn btn-outline">{t('tariffs.select')}</button>
        </div>
      ))}
    </div>
  );
};


// --- НОВЫЙ КОМПОНЕНТ: Форма техподдержки ---
const SupportSection = () => {
  const { t } = useTranslation(); 
  const { token } = useAuth();
  const [message, setMessage] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [success, setSuccess] = useState(null);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError(null);
    setSuccess(null);
    try {
      const response = await fetch('http://localhost:5000/api/client/support-tickets', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ message: message })
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data.message || 'Ошибка отправки');
      
      // Успех
      setSuccess("Сообщение успешно отправлено! Мы скоро ответим."); // TODO: Перевести
      setMessage(''); // Очищаем форму
      
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <section className="support-section">
      <h2>Связаться с поддержкой</h2>
      <p style={{color: '#aaa', marginTop: 0}}>
        Если у вас возникла проблема или есть вопрос, напишите нам.
      </p>
      
      <form className="support-form" onSubmit={handleSubmit}>
        <div className="form-group">
          <label htmlFor="support-message">Ваше сообщение:</label>
          <textarea
            id="support-message"
            rows="5"
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            placeholder="Опишите вашу проблему..."
            required
            disabled={loading}
          ></textarea>
        </div>
        
        {error && <div className="message-error" style={{marginBottom: '15px'}}>{error}</div>}
        {success && <div className="message-success" style={{marginBottom: '15px'}}>{success}</div>}
        
        <button type="submit" className="btn" style={{maxWidth: '200px'}} disabled={loading}>
          {loading ? 'Отправка...' : 'Отправить'}
        </button>
      </form>
    </section>
  );
};


// --- Основной компонент: DashboardPage ---
function DashboardPage() {
  const { t, i18n } = useTranslation(); 
  const { token, user, setUser, logout, currency, setCurrency } = useAuth();
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    // 1. Если user уже есть, мы просто синхронизируем язык/валюту
    if (user) { 
        setLoading(false); 
        // Синхронизируем язык, если он не совпадает
        if(user.preferred_lang && i18n.resolvedLanguage !== user.preferred_lang) {
            i18n.changeLanguage(user.preferred_lang);
        }
        // Синхронизируем валюту, если она не совпадает
        if(user.preferred_currency && currency !== user.preferred_currency) {
            setCurrency(user.preferred_currency);
            localStorage.setItem('userCurrency', user.preferred_currency);
        }
        return; 
    }
    // 2. Если токена нет, ждем
    if (!token) { setLoading(true); return; }

    // 3. Если user НЕТ, но токен ЕСТЬ (первая загрузка)
    const fetchMeData = async () => {
      setLoading(true); 
      try {
        const response = await fetch('http://localhost:5000/api/client/me', {
          headers: { 'Authorization': `Bearer ${token}` }
        });
        if (!response.ok) {
          if (response.status === 401) logout(); 
          throw new Error('Ошибка загрузки');
        }
        const data = await response.json();
        const userData = data.response || data;
        setUser(userData); 
        
        // 4. Устанавливаем язык И ВАЛЮТУ из БД при ПЕРВОЙ загрузке
        if(userData.preferred_lang && i18n.resolvedLanguage !== userData.preferred_lang) {
            i18n.changeLanguage(userData.preferred_lang);
        }
        if(userData.preferred_currency && currency !== userData.preferred_currency) {
            setCurrency(userData.preferred_currency);
            localStorage.setItem('userCurrency', userData.preferred_currency);
        }
      } catch (err) { setError(err.message); } 
      finally { setLoading(false); }
    };
    fetchMeData();
  }, [token, user, setUser, logout, i18n, currency, setCurrency]);


  // --- Рендеринг ---
  if (loading) return (
    <div className="dashboard-layout"><div className="loading-full">Загрузка...</div></div>
  );
  if (error) return (
    <div className="dashboard-layout"><div className="loading-full">Ошибка: {error}</div></div>
  );
  if (!user) return (
    <div className="dashboard-layout"><div className="loading-full">Нет данных.</div></div>
  );

  // --- Логика ---
  const isSubActive = user.activeInternalSquads && user.activeInternalSquads.length > 0;
  const expireDate = new Date(user.expireAt);
  const isExpired = expireDate < new Date();
  const isTrulyActive = isSubActive && !isExpired;
  const formattedDate = expireDate.toLocaleDateString(i18n.language, { day: '2-digit', month: '2-digit', year: 'numeric' }); 
  const squad = isSubActive ? user.activeInternalSquads[0] : null;
  const squadName = squad ? squad.name : "N/A";
  const referralLink = `http://localhost:3000/register?ref=${user.referral_code}`;

  return (
    <div className="dashboard-layout">
      {/* --- Верхняя панель --- */}
      <header className="dashboard-header">
        <div className="logo">STEALTHNET</div>
        <div className="user-menu">
          <LanguageCurrencySwitcher />
          <span className="user-email">{user.email}</span>
          <button onClick={logout} className="btn-text">{t('header.logout')}</button>
        </div>
      </header>

      <main className="dashboard-content">
        
        {/* --- Блок статуса --- */}
        <section className="status-section">
          <h2>{t('dashboard.title')}</h2>
          <div className={`status-card ${isTrulyActive ? 'active' : 'inactive'}`}>
            <div className="status-info">
              <span className="status-label">{t('dashboard.status')}</span>
              <span className="status-value">
                {isTrulyActive ? t('dashboard.status_active') : t('dashboard.status_inactive')}
              </span>
            </div>
            {(isTrulyActive) && (
              <div className="status-info">
                <span className="status-label">{t('dashboard.expires_at')}</span>
                <span className="status-value">{formattedDate}</span>
              </div>
            )}
            <div className="status-info">
              <span className="status-label">Тариф (Сквад):</span>
              <span className="status-value">{squadName}</span>
            </div>
            <div className="status-actions">
              {isTrulyActive ? (
                <ConnectButton url={user.subscriptionUrl} />
              ) : (
                <TrialButton onUpdateUser={(updatedUser) => setUser(updatedUser)} />
              )}
            </div>
          </div>
        </section>

        {/* --- Блок Реферальной ссылки --- */}
        {user.referral_code && (
          <section className="referral-section">
            <h2>{t('dashboard.referral_title')}</h2>
            <p>{t('dashboard.referral_desc')}</p>
            <div className="subscription-url-container" style={{marginTop: 0}}>
              <input 
                type="text" 
                value={referralLink} 
                readOnly 
                onClick={(e) => e.target.select()} 
              />
            </div>
          </section>
        )}

        {/* --- Блок серверов (только если активно) --- */}
        {isTrulyActive && (
          <section className="servers-section">
            <h2>{t('dashboard.servers')}</h2>
            <ServerList token={token} />
          </section>
        )}
        
        {/* --- НОВАЯ СЕКЦИЯ: ТЕХПОДДЕРЖКА --- */}
        <SupportSection />

        {/* --- Блок тарифов (ДИНАМИЧЕСКИЙ) --- */}
        <section className="tariffs-section">
          <h2>{t('dashboard.tariffs')}</h2>
          <TariffSection />
        </section>

      </main>
    </div>
  );
}

export default DashboardPage;